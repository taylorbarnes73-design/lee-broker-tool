# Lee Broker Tool — To-Do

## In Progress
- [ ] Wire SMTP email for `email.sendToAdmin` (currently falls back to `mailto:`)
- [ ] Confirm S3 bucket name + IAM credentials in Railway env vars

## Upcoming
- [ ] Dealius API: property snapshot fix (PropertySpaceID required in deal POST)
- [ ] Listing Entry → auto-push to Dealius as a new listing (not just deal)
- [ ] CoStar silver exposure tracker tab
- [ ] Sign order log with auto-sequenced PO numbers
- [ ] Voucher parser: refine `.xlsm` cell coordinate mapping against latest voucher version

## Done
- [x] Listing Entry form (all 4 property types, lease + sale)
- [x] Sign Request form + Cimarron-format PDF
- [x] Commission Voucher (8-step, rent schedule, commission distribution)
- [x] Comp Input (lease + sale)
- [x] Documents tab (60+ forms, searchable, collapsible sections)
- [x] Contracts tab (AIR CRE intake, PDF upload + AI extraction)
- [x] Admin Portal (submission dashboard, Dealius Deal Entry)
- [x] Broker Profiles (save agent details, pre-fill forms)
- [x] AI Field Assist panel (parse description → populate form)
- [x] Brochure upload + AI scrape → fill listing fields
- [x] Send to Admin modal (all 4 tabs) with mailto fallback
- [x] Remove all Manus platform dependencies
- [x] Migrate storage to AWS S3 with local fallback
- [x] Standardize env vars (OPENAI_API_KEY, S3_*, SMTP_*)
