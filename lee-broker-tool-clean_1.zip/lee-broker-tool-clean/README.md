# Lee & Associates Newport Beach — Broker Submission Tool

A full-stack broker admin tool for managing listings, sign requests, commission vouchers, comp submissions, and Dealius deal entry.

**Live:** https://lee-broker-tool-production.up.railway.app/broker_tool.html

---

## Features

| Tab | What it does |
|-----|-------------|
| **Listing Entry** | New listing + modification forms, AI brochure scrape, PDF export, Send to Admin |
| **Sign Request** | Sign order form with Cimarron-format PDF export, Send to Admin |
| **Commission Voucher** | 8-step voucher form with rent schedule, commission distribution, Send to Admin |
| **Comp Input** | Lease & sale comp forms with PDF export |
| **Documents** | Full library of Lee & Associates form downloads (searchable) |
| **Contracts** | AIR CRE contract intake — fill or upload PDF with AI field extraction |
| **Admin Portal** | Submission dashboard + Dealius Deal Entry (voucher → deal via API) |

---

## Stack

- **Server:** Node.js + Express + tRPC
- **Database:** MySQL via Drizzle ORM
- **Storage:** AWS S3 (local filesystem fallback in dev)
- **AI:** OpenAI (brochure scraping, field assist, Dealius AI review)
- **Build:** Vite + React (client) + esbuild (server)
- **Deploy:** Railway

---

## Setup

```bash
# 1. Install dependencies
pnpm install

# 2. Configure environment
cp .env.example .env
# Fill in DATABASE_URL, OPENAI_API_KEY, S3_*, SMTP_* as needed

# 3. Run database migrations
pnpm db:push

# 4. Start dev server
pnpm dev
```

The broker tool HTML is served at `/broker_tool.html` — no login required.

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | MySQL connection string |
| `OPENAI_API_KEY` | For AI features | Brochure scraping, field assist, AI review |
| `S3_BUCKET` | For file uploads | Falls back to local `.uploads/` in dev |
| `S3_REGION` | With S3 | AWS region (default: `us-east-1`) |
| `S3_ACCESS_KEY` | With S3 | AWS access key |
| `S3_SECRET_KEY` | With S3 | AWS secret key |
| `SMTP_HOST` | For email | Falls back to `mailto:` links if not set |
| `SMTP_PORT` | With SMTP | Default: `587` |
| `SMTP_USER` | With SMTP | SMTP username |
| `SMTP_PASS` | With SMTP | SMTP password |
| `SMTP_SECURE` | With SMTP | `true` for port 465, default `false` |
| `GOOGLE_MAPS_API_KEY` | Optional | Address geocoding |

---

## Deploy to Railway

1. Push to GitHub — Railway auto-deploys from `main`
2. Set env vars in Railway dashboard under **Variables**
3. Minimum required: `DATABASE_URL`, `NODE_ENV=production`

---

## Key Files

```
client/public/broker_tool.html   ← Main standalone broker tool (6,900+ lines)
server/routers.ts                ← tRPC API routes (files, email, auth)
server/storage.ts                ← S3 / local file storage
server/_core/env.ts              ← Environment variable config
server/_core/index.ts            ← Express server entry point
drizzle/schema.ts                ← Database schema
```

---

## Admin Portal

Access via the **Admin Portal** button in the header. Features:
- Submission dashboard with status tracking (Pending → In Review → Approved)
- **Dealius Deal Entry** — drop a `.xlsm` commission voucher to auto-parse and push to Dealius API
- Requires Dealius email/password (stored locally in browser)

For the Dealius API to work from the browser, install the [Allow CORS extension](https://chrome.google.com/webstore/detail/allow-cors-access-control/lhobafahddgcelffkeicbaginigeejlf) while using Deal Entry.
