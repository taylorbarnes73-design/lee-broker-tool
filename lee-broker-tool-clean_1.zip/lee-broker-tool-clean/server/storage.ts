// Storage helpers for Lee & Associates Broker Tool
// Supports AWS S3 (production) and local filesystem (development fallback)

import { ENV } from "./_core/env";
import path from "node:path";
import fs from "node:fs";

// ── S3 client (lazy-loaded so app boots without AWS creds in dev) ─────────────
async function getS3Client() {
  const { S3Client } = await import("@aws-sdk/client-s3");
  return new S3Client({
    region: ENV.s3Region || "us-east-1",
    credentials:
      ENV.s3AccessKey && ENV.s3SecretKey
        ? { accessKeyId: ENV.s3AccessKey, secretAccessKey: ENV.s3SecretKey }
        : undefined, // falls back to IAM role / env chain
  });
}

function normalizeKey(relKey: string): string {
  return relKey.replace(/^\/+/, "");
}

// ── Local dev fallback ────────────────────────────────────────────────────────
const LOCAL_UPLOAD_DIR = path.resolve(process.cwd(), ".uploads");

function localPut(key: string, data: Buffer, _contentType: string): string {
  const dest = path.join(LOCAL_UPLOAD_DIR, key);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, data);
  return `/uploads/${key}`;
}

function localGet(key: string): string {
  return `/uploads/${key}`;
}

// ── Public API ────────────────────────────────────────────────────────────────
export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream"
): Promise<{ key: string; url: string }> {
  const key = normalizeKey(relKey);
  const buffer = typeof data === "string" ? Buffer.from(data) : Buffer.from(data as Uint8Array);

  // Use S3 if bucket is configured, otherwise fall back to local
  if (ENV.s3Bucket) {
    const { PutObjectCommand } = await import("@aws-sdk/client-s3");
    const { getSignedUrl } = await import("@aws-sdk/s3-request-presigner");
    const s3 = await getS3Client();
    await s3.send(new PutObjectCommand({ Bucket: ENV.s3Bucket, Key: key, Body: buffer, ContentType: contentType }));
    // Return a presigned URL valid for 7 days
    const getCmd = (await import("@aws-sdk/client-s3")).GetObjectCommand;
    const url = await getSignedUrl(s3, new getCmd({ Bucket: ENV.s3Bucket, Key: key }), { expiresIn: 604800 });
    return { key, url };
  }

  const url = localPut(key, buffer, contentType);
  return { key, url };
}

export async function storageGet(relKey: string): Promise<{ key: string; url: string }> {
  const key = normalizeKey(relKey);

  if (ENV.s3Bucket) {
    const { GetObjectCommand } = await import("@aws-sdk/client-s3");
    const { getSignedUrl } = await import("@aws-sdk/s3-request-presigner");
    const s3 = await getS3Client();
    const url = await getSignedUrl(s3, new GetObjectCommand({ Bucket: ENV.s3Bucket, Key: key }), { expiresIn: 604800 });
    return { key, url };
  }

  return { key, url: localGet(key) };
}
