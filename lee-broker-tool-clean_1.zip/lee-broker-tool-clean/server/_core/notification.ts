/**
 * Notification helper (stubs — wire up email/Slack/webhook as needed).
 */
export async function notifyAdmin(subject: string, body: string): Promise<void> {
  // Log to console in dev; in production add your preferred notification channel
  console.info(`[notification] ${subject}\n${body}`);
}
