/**
 * Image generation helper.
 * Configure OPENAI_API_KEY to use DALL-E 3.
 */
import { ENV } from "./env";

export async function generateImage(prompt: string): Promise<string> {
  if (!ENV.openAiApiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
  const res = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { "Content-Type": "application/json", authorization: `Bearer ${ENV.openAiApiKey}` },
    body: JSON.stringify({ model: "dall-e-3", prompt, n: 1, size: "1024x1024" }),
  });
  if (!res.ok) throw new Error(`Image generation failed: ${res.statusText}`);
  const json = await res.json() as { data: { url: string }[] };
  return json.data[0].url;
}
