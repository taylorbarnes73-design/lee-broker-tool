/**
 * Generic data API helper (search, web fetch, etc.)
 * Configure OPENAI_API_KEY to enable AI-powered features.
 */
export async function searchWeb(query: string): Promise<unknown[]> {
  // Placeholder — wire up your preferred search API here
  console.warn("[dataApi] searchWeb called but no provider configured:", query);
  return [];
}
