/**
 * Google Maps API helper.
 * Set GOOGLE_MAPS_API_KEY to enable geocoding features.
 */
export async function geocodeAddress(address: string): Promise<{ lat: number; lng: number } | null> {
  const key = process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return null;
  const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${key}`;
  const res = await fetch(url);
  const json = await res.json() as { results: { geometry: { location: { lat: number; lng: number } } }[] };
  return json.results?.[0]?.geometry?.location ?? null;
}
