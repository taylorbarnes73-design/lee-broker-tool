/**
 * Voice transcription helper using OpenAI Whisper.
 * Configure OPENAI_API_KEY to enable.
 */
import { ENV } from "./env";

export async function transcribeAudio(audioBuffer: Buffer, mimeType = "audio/webm"): Promise<string> {
  if (!ENV.openAiApiKey) {
    throw new Error("OPENAI_API_KEY is not configured");
  }
  const form = new FormData();
  form.append("file", new Blob([audioBuffer], { type: mimeType }), "audio.webm");
  form.append("model", "whisper-1");
  const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { authorization: `Bearer ${ENV.openAiApiKey}` },
    body: form,
  });
  if (!res.ok) throw new Error(`Transcription failed: ${res.statusText}`);
  const json = await res.json() as { text: string };
  return json.text;
}
