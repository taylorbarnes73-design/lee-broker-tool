import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { storagePut, storageGet } from "./storage";
import { getDb } from "./db";
import { uploads } from "../drizzle/schema";
import { desc, eq } from "drizzle-orm";
import { z } from "zod/v4";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,

  email: router({
    /**
     * Send a form submission email to the admin.
     * Falls back gracefully — returns a mailto URL so the client
     * can open the user's mail app if server-side sending isn't configured.
     */
    sendToAdmin: publicProcedure
      .input(
        z.object({
          formType: z.string(),
          brokerName: z.string(),
          propertyAddress: z.string().optional(),
          sections: z.array(
            z.object({
              title: z.string(),
              fields: z.array(
                z.object({ label: z.string(), value: z.string() })
              ),
            })
          ),
          senderEmail: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { formType, brokerName, propertyAddress, sections, senderEmail } = input;

        const typeLabel: Record<string, string> = {
          listing: "Listing Entry",
          voucher: "Commission Voucher",
          sign: "Sign Request",
          comp: "Comp Input",
        };
        const label = typeLabel[formType] || formType;
        const subject = `[Lee & Associates] ${label} Submission${propertyAddress ? " — " + propertyAddress : ""}`;
        const adminEmail = "tbarnes@lee-associates.com";

        // Build plain-text email body
        const divider = "=".repeat(64);
        const lines: string[] = [
          `Lee & Associates Newport Beach — Broker Submission Tool`,
          divider,
          `${label.toUpperCase()} SUBMISSION`,
          `Submitted: ${new Date().toLocaleString("en-US", { timeZone: "America/Los_Angeles" })}`,
          `Submitted by: ${brokerName}`,
          divider,
        ];

        for (const section of sections) {
          const filled = section.fields.filter((f) => f.value && f.value.trim());
          if (filled.length === 0) continue;
          lines.push(`\n--- ${section.title.toUpperCase()} ---`);
          for (const field of filled) {
            lines.push(`  ${field.label}: ${field.value}`);
          }
        }

        lines.push(`\n${divider}`);
        lines.push(`Taylor Barnes | Lee & Associates Newport Beach`);

        const bodyText = lines.join("\n");

        // Try to send via nodemailer if SMTP env vars are configured
        let sent = false;
        const smtpHost = process.env.SMTP_HOST;
        const smtpUser = process.env.SMTP_USER;
        const smtpPass = process.env.SMTP_PASS;

        if (smtpHost && smtpUser && smtpPass) {
          try {
            // Dynamic import so the app works without nodemailer installed
            const nodemailer = await import("nodemailer");
            const transporter = nodemailer.createTransport({
              host: smtpHost,
              port: parseInt(process.env.SMTP_PORT || "587"),
              secure: process.env.SMTP_SECURE === "true",
              auth: { user: smtpUser, pass: smtpPass },
            });
            await transporter.sendMail({
              from: senderEmail || smtpUser,
              to: adminEmail,
              cc: senderEmail || undefined,
              subject,
              text: bodyText,
            });
            sent = true;
          } catch (err) {
            console.error("[email.sendToAdmin] SMTP error:", err);
          }
        }

        // Always return the mailto URL as a fallback the client can use
        const mailtoUrl =
          `mailto:${adminEmail}` +
          `?subject=${encodeURIComponent(subject)}` +
          `&body=${encodeURIComponent(bodyText)}` +
          (senderEmail ? `&cc=${encodeURIComponent(senderEmail)}` : "");

        return { success: true, sent, mailtoUrl };
      }),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  files: router({
    /**
     * Upload a file to S3 and record metadata in the database.
     * The client sends the file as a base64-encoded string.
     */
    upload: publicProcedure
      .input(
        z.object({
          filename: z.string(),
          mimeType: z.string(),
          base64Data: z.string(),
          category: z.string().default("other"),
          reference: z.string().optional(),
          uploaderName: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { filename, mimeType, base64Data, category, reference, uploaderName } = input;

        // Decode base64 to buffer
        const buffer = Buffer.from(base64Data, "base64");
        const fileSize = buffer.length;

        // Build a unique S3 key with random suffix to prevent enumeration
        const ext = filename.split(".").pop() ?? "bin";
        const safeName = filename.replace(/[^a-zA-Z0-9._-]/g, "_");
        const fileKey = `broker-docs/${category}/${nanoid(10)}-${safeName}`;

        // Upload to S3
        const { url } = await storagePut(fileKey, buffer, mimeType);

        // Save metadata to database
        const db = await getDb();
        if (db) {
          await db.insert(uploads).values({
            fileKey,
            url,
            filename,
            mimeType,
            fileSize,
            category,
            reference: reference ?? null,
            uploaderName: uploaderName ?? null,
          });
        }

        return { success: true, url, fileKey, filename };
      }),

    /**
     * Get a fresh download URL for a file by its key.
     */
    getUrl: publicProcedure
      .input(z.object({ fileKey: z.string() }))
      .query(async ({ input }) => {
        const { url } = await storageGet(input.fileKey);
        return { url };
      }),

    /**
     * List recent uploads, optionally filtered by category or reference.
     */
    list: publicProcedure
      .input(
        z.object({
          category: z.string().optional(),
          reference: z.string().optional(),
          limit: z.number().default(50),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        const rows = await db
          .select()
          .from(uploads)
          .orderBy(desc(uploads.createdAt))
          .limit(input.limit);

        // Filter in JS if needed (simple approach)
        return rows.filter(r => {
          if (input.category && r.category !== input.category) return false;
          if (input.reference && r.reference !== input.reference) return false;
          return true;
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
