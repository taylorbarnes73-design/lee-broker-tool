
  # Request Submission Website

  This is a code bundle for Request Submission Website. The original project is available at https://www.figma.com/design/Qhg3VfenvC3QXv5g2gmzTC/Request-Submission-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  