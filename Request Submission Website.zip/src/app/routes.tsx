import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { SubmitRequest } from "./pages/SubmitRequest";
import { MyRequests } from "./pages/MyRequests";
import { RequestWorkflow } from "./pages/RequestWorkflow";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "submit", Component: SubmitRequest },
      { path: "requests", Component: MyRequests },
      { path: "workflow", Component: RequestWorkflow },
      { path: "*", Component: NotFound },
    ],
  },
]);
